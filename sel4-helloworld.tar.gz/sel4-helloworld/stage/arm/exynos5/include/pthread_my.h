#ifndef __PTHREAD_MY_H
#define __PTHREAD_MY_H
#include <autoconf.h>

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <limits.h>

#include <platsupport/timer.h>

#include <sel4platsupport/platsupport.h>
#include <sel4platsupport/plat/timer.h>
#include <sel4utils/vspace.h>
#include <sel4utils/stack.h>
#include <sel4utils/process.h>

#include <simple/simple.h>

#include <simple-default/simple-default.h>


#include <utils/util.h>

#include <vka/object.h>
#include <vka/capops.h>

#include <vspace/vspace.h>

#include <atomic.h>

typedef seL4_Word sel4_pthread_t;

/* environment encapsulating allocation interfaces etc */
typedef struct sel4_pthread_env_t
{
    /* An initialized vka that may be used by the test. */
    vka_t vka;
    /* virtual memory management interface */
    vspace_t vspace;
    /* abstracts over kernel version and boot environment */
    simple_t simple;

    seL4_CPtr cnodeCap;

    seL4_Word emptyStart;

    seL4_Word emptyEnd;

    seL4_CPtr memoryCap;


}sel4_pthread_env_t;

typedef struct sel4_pthread_attr_t
{
    unsigned int      detachstate:2,
                      stackaddr_valid:1,
                      stacksize_valid:1;
    /*tid*/
    seL4_Word sel4_tcb_tid;
      /* thread stack address*/
    void *stackaddr;
    /* thread stack size*/
    size_t   stacksize;

}sel4_pthread_attr_t;

#define PTHREAD_MUTEX_NORMAL 0
#define PTHREAD_MUTEX_DEFAULT 0
#define PTHREAD_MUTEX_RECURSIVE 1
#define PTHREAD_MUTEX_ERRORCHECK 2

#define PTHREAD_CREATE_JOINABLE	        1
#define PTHREAD_CREATE_DETACHED	        2
#define __SU (sizeof(size_t)/sizeof(int))
#define _a_stacksize __u.__s[0]
#define _a_guardsize __u.__s[1]
#define _a_stackaddr __u.__s[2]
#define _a_detach __u.__i[3*__SU+0]
#define _a_sched __u.__i[3*__SU+1]
#define _a_policy __u.__i[3*__SU+2]
#define _a_prio __u.__i[3*__SU+3]
#define _m_type __u.__i[0]
#define _m_lock __u.__i[1]
#define _m_waiters __u.__i[2]
#define _m_prev __u.__p[3]
#define _m_next __u.__p[4]
#define _m_count __u.__i[5]
#define _c_shared __u.__p[0]
#define _c_seq __u.__i[2]
#define _c_waiters __u.__i[3]
#define _c_clock __u.__i[4]
#define _c_lock __u.__i[8]
#define _c_head __u.__p[1]
#define _c_tail __u.__p[5]
#define _rw_lock __u.__i[0]
#define _rw_waiters __u.__i[1]
#define _rw_shared __u.__i[2]
#define _b_lock __u.__i[0]
#define _b_waiters __u.__i[1]
#define _b_limit __u.__i[2]
#define _b_count __u.__i[3]
#define _b_waiters2 __u.__i[4]
#define _b_inst __u.__p[3]

sel4_pthread_env_t env;

sel4_pthread_t thread_self ();

int sel4_pthread_env_init(sel4_pthread_env_t *env);

int sel4_pthread_attr_init(sel4_pthread_attr_t *attr);

int pthread_attr_destroy (sel4_pthread_attr_t *attr);

int sel4_pthread_create(sel4_pthread_t *thread ,const sel4_pthread_attr_t *attr,void *(*start_routine) (void *) ,void *arg);

int pthread_cancel (sel4_pthread_t thread);

int pthread_equal (sel4_pthread_t thread1, sel4_pthread_t thread2);

int sel4_pthread_yield(void);

// Set the detachstate attribute
int pthread_attr_setdetachstate (sel4_pthread_attr_t *attr,
                                         int detachstate);

int pthread_attr_getdetachstate (const sel4_pthread_attr_t *attr,int *detachstate);

// Set scheduling parameters
int sel4_pthread_attr_setschedparam (sel4_pthread_attr_t *attr,
				       const seL4_Word *sel4_tcb_tid);

// Get scheduling parameters
int pthread_attr_getschedparam (const sel4_pthread_attr_t *attr,
                                        seL4_Word *sel4_tcb_tid);

int sel4_pthread_join(sel4_pthread_t thread);

// Set starting address of stack. Whether this is at the start or end of
// the memory block allocated for the stack depends on whether the stack
// grows up or down.
int sel4_pthread_attr_setstackaddr (sel4_pthread_attr_t *attr, const void  *stackaddr);

// Get any previously set stack address.
int sel4_pthread_attr_getstackaddr (const sel4_pthread_attr_t *attr,
                                        void *stackaddr);


// Set minimum creation stack size.
int sel4_pthread_attr_setstacksize (sel4_pthread_attr_t *attr,
                                       size_t stacksize);

// Get current minimal stack size.
int sel4_pthread_attr_getstacksize (const sel4_pthread_attr_t *attr,
                                       size_t *stacksize);

int sel4_pthread_mutex_init (pthread_mutex_t *mutex,
                                const pthread_mutexattr_t *mutex_attr);

int sel4_pthread_mutex_destroy (pthread_mutex_t *mutex);

// Try to lock mutex.
int sel4_pthread_mutex_trylock (pthread_mutex_t *mutex);

int sel4_pthread_mutex_lock (pthread_mutex_t *mutex);

// Unlock mutex.
int sel4_pthread_mutex_unlock (pthread_mutex_t *mutex);         

#endif
